package model

type Technology struct {
	Name    string `json:"name"`
	Details string `json:"details"`
}
