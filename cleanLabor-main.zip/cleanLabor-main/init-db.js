db.tech.insert({
    "name": "Go",
    "details": "An open source programming language that makes it easy to build simple and efficient software."
});
db.tech.insert({
    "name": "JavaScript",
    "details": "A lightweight, interpreted, or just-in-time compiled programming language with first-class functions."
});
db.tech.insert({
    "name": "MongoDB",
    "details": "A general purpose, document-based, distributed database."
});
